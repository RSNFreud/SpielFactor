<?php get_header(); ?>


	<div id="notfound">
		<div class="notfound">
			<div class="notfound-404">
				<?php get_template_part( 'content-404', get_post_format() );?>
			</div>
		</div>
	</div>


<?php get_footer(); ?>