<div class="col-sm-3" id="sidebar">
		<div class="countdowntitle">
			Countdown till Spiel Factor
		</div>
		<div class="feed">
			<p id="demo"></p>
		</div>
	</div><!-- /.blog-sidebar -->