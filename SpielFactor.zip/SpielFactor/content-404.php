<div class="errortitle">Error 404:</div>
<div class="errortext">this page doesnt exist! <a href="<?php echo get_bloginfo( 'wpurl' );?>">click here</a> to go back to the home page!
</div><!-- /.blog-post -->