<div class="title">
	<?php the_title(); ?>
</div>
<div class="content">
	<?php the_content(); ?>
</div><!-- /.blog-post -->